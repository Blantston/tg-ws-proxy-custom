use crate::config::*;
use crate::ws::{is_http_status_error, ws_connect_once, RawWebSocket, WsError};
use crate::{ldebug, lerror, linfo, lwarn};
use serde::Deserialize;
use std::path::PathBuf;
use std::time::{Duration, Instant};
use tokio::sync::Semaphore;

use once_cell::sync::Lazy;
static CFPROXY_SEM: Lazy<Semaphore> = Lazy::new(|| Semaphore::new(CFPROXY_GLOBAL_PARALLEL));

// ---------------------------------------------------------------------------
// Domain decoding
// ---------------------------------------------------------------------------

pub fn decode_cf_domain(s: &str) -> String {
    if !s.ends_with(".com") {
        return s.to_string();
    }
    let suffix = ".co.uk";
    let p = &s[..s.len() - 4];
    let mut n = 0i32;
    for c in p.chars() {
        if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') {
            n += 1;
        }
    }
    let mut result: Vec<u8> = Vec::new();
    for &c in p.as_bytes() {
        if c >= b'a' && c <= b'z' {
            let v = (((c - b'a') as i32 - n % 26 + 26) % 26) as u8 + b'a';
            result.push(v);
        } else if c >= b'A' && c <= b'Z' {
            let v = (((c - b'A') as i32 - n % 26 + 26) % 26) as u8 + b'A';
            result.push(v);
        } else {
            result.push(c);
        }
    }
    let mut out = String::from_utf8_lossy(&result).to_string();
    out.push_str(suffix);
    out
}

pub fn normalize_cf_domain(s: &str) -> String {
    let mut decoded = decode_cf_domain(s.trim()).trim().to_lowercase();
    while decoded.ends_with('.') {
        decoded.pop();
    }
    if decoded.is_empty() || !decoded.ends_with(".co.uk") {
        return String::new();
    }
    decoded
}

pub fn default_cfproxy_domains() -> Vec<String> {
    let mut domains = Vec::with_capacity(CFPROXY_ENC.len());
    for enc in CFPROXY_ENC {
        let d = normalize_cf_domain(enc);
        if !d.is_empty() {
            domains.push(d);
        }
    }
    domains
}

pub fn merge_cfproxy_domains(lists: &[Vec<String>]) -> Vec<String> {
    let mut seen = std::collections::HashSet::new();
    let mut merged = Vec::new();
    for list in lists {
        for raw in list {
            let d = normalize_cf_domain(raw);
            if d.is_empty() || seen.contains(&d) {
                continue;
            }
            seen.insert(d.clone());
            merged.push(d);
        }
    }
    merged
}

// ---------------------------------------------------------------------------
// 429 cooldown logic
// ---------------------------------------------------------------------------

pub fn clear_cfproxy_429_cooldowns() {
    CFPROXY_429.write().clear();
}

pub fn clear_cfproxy_429_cooldown(domain: &str) {
    let d = normalize_cf_domain(domain);
    if d.is_empty() {
        return;
    }
    CFPROXY_429.write().remove(&d);
}

pub fn retry_after_delay(err: &WsError) -> Duration {
    let h = match err.handshake() {
        Some(h) => h,
        None => return Duration::ZERO,
    };
    let retry_after = h.headers.get("retry-after").map(|s| s.trim()).unwrap_or("");
    if retry_after.is_empty() {
        return Duration::ZERO;
    }
    if let Ok(seconds) = retry_after.parse::<i64>() {
        if seconds > 0 {
            return Duration::from_secs(seconds as u64);
        }
    }
    // http date parse (best-effort): пропускаем, как маловероятный кейс
    Duration::ZERO
}

pub fn next_cfproxy_429_cooldown_delay(prev: &Cfproxy429State, retry_after: Duration) -> Duration {
    if retry_after > Duration::ZERO {
        if retry_after > CFPROXY_429_MAX_COOLDOWN {
            return CFPROXY_429_MAX_COOLDOWN;
        }
        return retry_after;
    }
    let mut strikes = prev.strikes;
    let expired = match prev.until {
        None => true,
        Some(u) => u.elapsed() > CFPROXY_429_MAX_COOLDOWN,
    };
    if expired {
        strikes = 0;
    }
    let mut delay = CFPROXY_429_COOLDOWN;
    for _ in 0..strikes {
        delay *= 2;
        if delay >= CFPROXY_429_MAX_COOLDOWN {
            return CFPROXY_429_MAX_COOLDOWN;
        }
    }
    if delay > CFPROXY_429_MAX_COOLDOWN {
        return CFPROXY_429_MAX_COOLDOWN;
    }
    delay
}

pub fn mark_cfproxy_429_cooldown(domain: &str, err: &WsError) {
    let d = normalize_cf_domain(domain);
    if d.is_empty() {
        return;
    }
    let retry_after = retry_after_delay(err);
    let mut map = CFPROXY_429.write();
    let prev = map.get(&d).cloned().unwrap_or_default();
    let delay = next_cfproxy_429_cooldown_delay(&prev, retry_after);
    let mut strikes = prev.strikes + 1;
    let expired = match prev.until {
        None => true,
        Some(u) => u.elapsed() > CFPROXY_429_MAX_COOLDOWN,
    };
    if expired {
        strikes = 1;
    }
    map.insert(
        d.clone(),
        Cfproxy429State {
            until: Some(Instant::now() + delay),
            strikes,
        },
    );
    drop(map);
    ldebug!(" CF cooldown {}: {:.0}s after 429", d, delay.as_secs_f64().ceil());
}

pub fn cfproxy_429_cooldown_remaining(domain: &str) -> Duration {
    let d = normalize_cf_domain(domain);
    if d.is_empty() {
        return Duration::ZERO;
    }
    let map = CFPROXY_429.read();
    let state = match map.get(&d) {
        Some(s) => s.clone(),
        None => return Duration::ZERO,
    };
    drop(map);
    let until = match state.until {
        Some(u) => u,
        None => return Duration::ZERO,
    };
    let now = Instant::now();
    if until <= now {
        CFPROXY_429.write().remove(&d);
        return Duration::ZERO;
    }
    until - now
}

pub async fn acquire_cfproxy_attempt_slot() -> Option<tokio::sync::SemaphorePermit<'static>> {
    CFPROXY_SEM.acquire().await.ok()
}

// ---------------------------------------------------------------------------
// Cache files
// ---------------------------------------------------------------------------

fn cfproxy_cache_path() -> Option<PathBuf> {
    let dir = CFPROXY.read().cache_dir.trim().to_string();
    if dir.is_empty() {
        return None;
    }
    Some(PathBuf::from(dir).join(CFPROXY_CACHE_FILE_NAME))
}

fn cfproxy_active_domain_path() -> Option<PathBuf> {
    let dir = CFPROXY.read().cache_dir.trim().to_string();
    if dir.is_empty() {
        return None;
    }
    Some(PathBuf::from(dir).join(CFPROXY_ACTIVE_FILE_NAME))
}

fn load_cfproxy_domains_from_cache() -> Vec<String> {
    let path = match cfproxy_cache_path() {
        Some(p) => p,
        None => return Vec::new(),
    };
    let data = match std::fs::read_to_string(&path) {
        Ok(d) => d,
        Err(_) => return Vec::new(),
    };
    let list: Vec<String> = data.split('\n').map(|s| s.to_string()).collect();
    merge_cfproxy_domains(&[list])
}

fn load_active_cfproxy_domain() -> String {
    let path = match cfproxy_active_domain_path() {
        Some(p) => p,
        None => return String::new(),
    };
    let data = match std::fs::read_to_string(&path) {
        Ok(d) => d,
        Err(_) => return String::new(),
    };
    normalize_cf_domain(&data)
}

fn save_cfproxy_domains_to_cache(domains: &[String]) {
    let path = match cfproxy_cache_path() {
        Some(p) => p,
        None => return,
    };
    if domains.is_empty() {
        return;
    }
    if let Some(parent) = path.parent() {
        if let Err(e) = std::fs::create_dir_all(parent) {
            ldebug!(" CF: кеш создать не удалось: {}", e);
            return;
        }
    }
    let data = domains.join("\n");
    if let Err(e) = std::fs::write(&path, data) {
        ldebug!(" CF: кеш сохранить не удалось: {}", e);
    }
}

fn save_active_cfproxy_domain(domain: &str) {
    let path = match cfproxy_active_domain_path() {
        Some(p) => p,
        None => return,
    };
    let d = normalize_cf_domain(domain);
    if d.is_empty() {
        return;
    }
    if let Some(parent) = path.parent() {
        if let Err(e) = std::fs::create_dir_all(parent) {
            ldebug!(" CF: active-domain кеш создать не удалось: {}", e);
            return;
        }
    }
    if let Err(e) = std::fs::write(&path, d) {
        ldebug!(" CF: active-domain кеш сохранить не удалось: {}", e);
    }
}

fn should_refresh_cfproxy_domains() -> bool {
    let path = match cfproxy_cache_path() {
        Some(p) => p,
        None => return true,
    };
    let meta = match std::fs::metadata(&path) {
        Ok(m) => m,
        Err(_) => return true,
    };
    let modified = match meta.modified() {
        Ok(t) => t,
        Err(_) => return true,
    };
    match modified.elapsed() {
        Ok(elapsed) => elapsed >= CFPROXY_REFRESH_INTERVAL,
        Err(_) => true,
    }
}

fn set_active_cfproxy_domain_locked(cfg: &mut CfproxyConfig, preferred: &str) {
    if cfg.domains.is_empty() {
        cfg.active = String::new();
        return;
    }
    let preferred = normalize_cf_domain(preferred);
    for d in &cfg.domains {
        if *d == preferred {
            cfg.active = d.clone();
            return;
        }
    }
    cfg.active = cfg.domains[0].clone();
}

pub fn init_cfproxy_domains() {
    let defaults = default_cfproxy_domains();
    let cached = load_cfproxy_domains_from_cache();
    let persisted_active = load_active_cfproxy_domain();

    let mut cfg = CFPROXY.write();
    if !cfg.user_domain.is_empty() {
        let ud = cfg.user_domain.clone();
        cfg.domains = vec![ud.clone()];
        cfg.active = ud;
        return;
    }

    if !cached.is_empty() {
        let n = cached.len();
        cfg.domains = merge_cfproxy_domains(&[cached, defaults]);
        drop(cfg);
        linfo!(" CF: кеш доменов загружен ({} шт.)", n);
        let mut cfg = CFPROXY.write();
        set_active_cfproxy_domain_locked(&mut cfg, &persisted_active);
    } else {
        cfg.domains = defaults;
        set_active_cfproxy_domain_locked(&mut cfg, &persisted_active);
    }
}

pub fn start_cfproxy_refresh() {
    if !should_refresh_cfproxy_domains() {
        ldebug!(" CF: кеш свежий, пропускаю обновление списка");
        return;
    }
    tokio::spawn(async move {
        for _ in 0..3 {
            if try_refresh_cfproxy_domains().await {
                return;
            }
            tokio::time::sleep(Duration::from_secs(10)).await;
        }
        ldebug!(" CF: обновить список доменов не удалось, остаюсь на кеше/встроенном списке");
    });
}

pub async fn try_refresh_cfproxy_domains() -> bool {
    let has_user = !CFPROXY.read().user_domain.is_empty();
    if has_user {
        return true;
    }

    let client = match reqwest::Client::builder()
        .timeout(Duration::from_secs(10))
        .build()
    {
        Ok(c) => c,
        Err(_) => return false,
    };

    let resp = match client
        .get(CFPROXY_DOMAINS_URL)
        .header("User-Agent", "Mozilla/5.0 tg-ws-proxy-android")
        .send()
        .await
    {
        Ok(r) => r,
        Err(e) => {
            ldebug!(" CF: GitHub недоступен: {}", e);
            return false;
        }
    };
    if resp.status().as_u16() != 200 {
        ldebug!(" CF: GitHub вернул {}", resp.status().as_u16());
        return false;
    }
    let body = match resp.text().await {
        Ok(b) => b,
        Err(e) => {
            ldebug!(" CF: список доменов прочитать не удалось: {}", e);
            return false;
        }
    };

    let mut new_domains = Vec::new();
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let d = normalize_cf_domain(line);
        if !d.is_empty() {
            new_domains.push(d);
        }
    }

    if !new_domains.is_empty() {
        let merged = merge_cfproxy_domains(&[new_domains.clone(), default_cfproxy_domains()]);
        {
            let mut cfg = CFPROXY.write();
            if !cfg.user_domain.is_empty() {
                return true;
            }
            let current_active = cfg.active.clone();
            cfg.domains = merged.clone();
            set_active_cfproxy_domain_locked(&mut cfg, &current_active);
        }
        save_cfproxy_domains_to_cache(&merged);
        linfo!(" CF: список доменов обновлен ({} шт.)", new_domains.len());
        return true;
    }
    false
}

// ---------------------------------------------------------------------------
// DNS over HTTPS (DoH) resolve
// ---------------------------------------------------------------------------

#[derive(Deserialize)]
struct DohAnswer {
    #[serde(rename = "data")]
    data: String,
    #[serde(rename = "type")]
    type_: i32,
}
#[derive(Deserialize)]
struct DohResponse {
    #[serde(rename = "Answer", default)]
    answer: Vec<DohAnswer>,
}

static DOH_CACHE: Lazy<parking_lot::RwLock<std::collections::HashMap<String, (Vec<String>, Instant)>>> =
    Lazy::new(|| parking_lot::RwLock::new(std::collections::HashMap::new()));

pub async fn resolve_doh_all(domain: &str) -> Vec<String> {
    if let Some((ips, exp)) = DOH_CACHE.read().get(domain).cloned() {
        if Instant::now() < exp && !ips.is_empty() {
            return ips;
        }
    }

    let endpoints = [
        "https://cloudflare-dns.com/dns-query",
        "https://dns.google/dns-query",
        "https://dns.quad9.net/dns-query",
        "https://dns.adguard-dns.com/dns-query",
    ];

    let client = match reqwest::Client::builder()
        .timeout(Duration::from_millis(1800))
        .build()
    {
        Ok(c) => c,
        Err(_) => return Vec::new(),
    };

    let (tx, mut rx) = tokio::sync::mpsc::channel::<Vec<String>>(endpoints.len() + 1);
    let mut tasks = Vec::new();

    for endpoint in endpoints {
        let client = client.clone();
        let name = domain.to_string();
        let tx = tx.clone();
        tasks.push(tokio::spawn(async move {
            let url = format!("{}?name={}&type=A", endpoint, name);
            let mut ips = Vec::new();
            if let Ok(resp) = client
                .get(&url)
                .header("Accept", "application/dns-json")
                .send()
                .await
            {
                if resp.status().as_u16() == 200 {
                    if let Ok(response) = resp.json::<DohResponse>().await {
                        for answer in response.answer {
                            if answer.type_ != 1 {
                                continue;
                            }
                            if let Ok(std::net::IpAddr::V4(ip)) = answer.data.parse::<std::net::IpAddr>() {
                                let value = ip.to_string();
                                if !ips.contains(&value) {
                                    ips.push(value);
                                }
                            }
                        }
                    }
                }
            }
            let _ = tx.send(ips).await;
        }));
    }

    // Системный resolver — ещё один независимый источник A-записей.
    {
        let name = domain.to_string();
        let tx = tx.clone();
        tasks.push(tokio::spawn(async move {
            let mut ips = Vec::new();
            if let Ok(Ok(addrs)) = tokio::time::timeout(
                Duration::from_millis(1500),
                tokio::net::lookup_host(format!("{}:443", name)),
            )
            .await
            {
                for address in addrs {
                    if let std::net::IpAddr::V4(ip) = address.ip() {
                        let value = ip.to_string();
                        if !ips.contains(&value) {
                            ips.push(value);
                        }
                    }
                }
            }
            let _ = tx.send(ips).await;
        }));
    }

    drop(tx);
    let deadline = tokio::time::sleep(Duration::from_millis(1800));
    tokio::pin!(deadline);

    let mut resolved = Vec::new();
    loop {
        tokio::select! {
            _ = &mut deadline => break,
            message = rx.recv() => match message {
                Some(ips) if !ips.is_empty() => {
                    resolved = ips;
                    break;
                }
                Some(_) => {}
                None => break,
            }
        }
    }

    for task in tasks {
        task.abort();
    }

    // Ограничиваем fan-out, сохраняя несколько независимых Cloudflare anycast IP.
    resolved.truncate(4);
    if !resolved.is_empty() {
        DOH_CACHE.write().insert(
            domain.to_string(),
            (resolved.clone(), Instant::now() + Duration::from_secs(300)),
        );
    }
    resolved
}

pub async fn resolve_doh(domain: &str) -> Option<String> {
    resolve_doh_all(domain).await.into_iter().next()
}

// ---------------------------------------------------------------------------
// cfConnectDomain
// ---------------------------------------------------------------------------

fn new_timed_attempt_timeout(base: Duration, phase: Duration) -> Duration {
    let mut eff = base;
    if eff <= Duration::ZERO {
        eff = Duration::from_secs(5);
    }
    if eff > phase {
        eff = phase;
    }
    eff
}

pub async fn cf_connect_domain(
    domain: &str,
    path: &str,
    timeout: f64,
) -> (Option<RawWebSocket>, String, Option<WsError>) {
    let path = if path.is_empty() { "/apiws" } else { path };

    let attempt_timeout = crate::ws::ws_connect_timeout(timeout);
    let phase_timeout = attempt_timeout.min(CFPROXY_DIAL_PHASE_TIMEOUT);

    match ws_connect_once(domain, domain, path, phase_timeout).await {
        Ok(ws) => return (Some(ws), String::new(), None),
        Err(host_error) => {
            if is_http_status_error(&host_error, 429) {
                return (None, String::new(), Some(host_error));
            }

            let ips = resolve_doh_all(domain).await;
            if ips.is_empty() {
                let error = WsError::Fallback {
                    hostname_error: host_error.compact(),
                    ip_errors: Vec::new(),
                    final_error: Box::new(WsError::Other("DoH: no IPv4 answer within the DNS deadline".to_string())),
                };
                return (None, String::new(), Some(error));
            }

            // Проверяем несколько A-записей параллельно: первый адрес из DNS
            // может быть недоступен на конкретном операторе, хотя соседний отвечает.
            let mut attempts = tokio::task::JoinSet::new();
            for ip in ips.iter().cloned() {
                let domain = domain.to_string();
                let path = path.to_string();
                attempts.spawn(async move {
                    let result = ws_connect_once(&ip, &domain, &path, phase_timeout).await;
                    (ip, result)
                });
            }

            let mut ip_errors: Vec<(String, String)> = Vec::new();
            let mut final_error: Option<WsError> = None;
            while let Some(joined) = attempts.join_next().await {
                let (ip, result) = match joined {
                    Ok(value) => value,
                    Err(_) => continue,
                };
                match result {
                    Ok(ws) => {
                        attempts.abort_all();
                        return (Some(ws), ip, None);
                    }
                    Err(error) => {
                        if is_http_status_error(&error, 429) {
                            attempts.abort_all();
                            return (None, ip, Some(error));
                        }
                        ip_errors.push((ip, error.compact()));
                        final_error = Some(error);
                    }
                }
            }

            let tried_ips = ips.join(",");
            let final_error = final_error.unwrap_or_else(|| WsError::Other("all IP attempts were canceled".to_string()));
            let combined = WsError::Fallback {
                hostname_error: host_error.compact(),
                ip_errors,
                final_error: Box::new(final_error),
            };
            (None, tried_ips, Some(combined))
        }
    }
}

pub fn log_cf_conn_error(msg: &str, err: &WsError) {
    if let WsError::Io(ref e) = err {
        if e.kind() == std::io::ErrorKind::ConnectionReset {
            return;
        }
    }
    if is_http_status_error(err, 429) {
        lwarn!("{}", msg);
    } else {
        lerror!("{}", msg);
    }
}

// активный домен set/save
pub fn set_active_domain_and_save(chosen: &str) {
    let prev_active = CFPROXY.read().active.clone();
    if !chosen.is_empty() && chosen != prev_active {
        {
            let mut cfg = CFPROXY.write();
            cfg.active = chosen.to_string();
        }
        let chosen_owned = chosen.to_string();
        if tokio::runtime::Handle::try_current().is_ok() {
            tokio::task::spawn_blocking(move || {
                save_active_cfproxy_domain(&chosen_owned);
            });
        } else {
            save_active_cfproxy_domain(&chosen_owned);
        }
        linfo!(" CF домен  {}", chosen);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decodes_embedded_domain_list_entry() {
        assert_eq!(decode_cf_domain("virkgj.com"), "pclead.co.uk");
    }

    #[test]
    fn normalizes_only_supported_proxy_domains() {
        assert_eq!(normalize_cf_domain("KWS2.NothingThere.CO.UK."), "kws2.nothingthere.co.uk");
        assert_eq!(normalize_cf_domain("example.com"), "");
    }

    #[test]
    fn merges_domain_lists_without_duplicates() {
        let merged = merge_cfproxy_domains(&[
            vec!["pclead.co.uk".to_string(), "Pclead.co.uk".to_string()],
            vec!["offshor.co.uk".to_string()],
        ]);
        assert_eq!(merged, vec!["pclead.co.uk", "offshor.co.uk"]);
    }
}
